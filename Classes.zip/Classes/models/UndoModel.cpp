#include "UndoModel.h"
#include "cocos2d.h"

USING_NS_CC;

UndoModel::UndoModel(size_t maxStackSize)
    : _maxStackSize(maxStackSize) {
    CCLOG("UndoModel created with max stack size: %zu", maxStackSize);
}

void UndoModel::pushAction(const UndoAction& action) {
    _actions.push_back(action);
    trimStack();

    CCLOG("Undo action pushed: type=%d, cardId=%d, stackSize=%zu",
        static_cast<int>(action.type), action.cardId, _actions.size());
}

UndoAction UndoModel::popAction() {
    if (_actions.empty()) {
        // ��ʵ����Ŀ��Ӧ��ʹ�ø����ʵ��쳣����
        CCLOGERROR("Attempt to pop from empty undo stack");
        throw std::runtime_error("Undo stack is empty");
    }

    UndoAction action = _actions.back();
    _actions.pop_back();

    CCLOG("Undo action popped: type=%d, cardId=%d, remaining=%zu",
        static_cast<int>(action.type), action.cardId, _actions.size());

    return action;
}

const UndoAction& UndoModel::peekAction() const {
    if (_actions.empty()) {
        CCLOGERROR("Attempt to peek empty undo stack");
        throw std::runtime_error("Undo stack is empty");
    }

    return _actions.back();
}

void UndoModel::clear() {
    size_t previousSize = _actions.size();
    _actions.clear();
    CCLOG("Undo stack cleared, previous size: %zu", previousSize);
}

void UndoModel::setMaxStackSize(size_t maxSize) {
    _maxStackSize = maxSize;
    trimStack();
    CCLOG("Undo stack max size set to: %zu", maxSize);
}

void UndoModel::serialize() const {
    CCLOG("UndoModel serialization: %zu actions", _actions.size());
    // TODO: ʵ�����л��߼�
    // ��ʵ����Ŀ�У�����Ὣ�������ݱ��浽�ļ����ڴ���
}

void UndoModel::deserialize() {
    CCLOG("UndoModel deserialization not yet implemented");
    // TODO: ʵ�ַ����л��߼�
    // ��ʵ����Ŀ�У��������ļ����ڴ��м��ػ�������
}

void UndoModel::trimStack() {
    if (_maxStackSize > 0 && _actions.size() > _maxStackSize) {
        // �Ƴ���ɵĲ�����ջ�ף�
        size_t removeCount = _actions.size() - _maxStackSize;
        _actions.erase(_actions.begin(), _actions.begin() + removeCount);

        CCLOG("Undo stack trimmed, removed %zu oldest actions", removeCount);
    }
}